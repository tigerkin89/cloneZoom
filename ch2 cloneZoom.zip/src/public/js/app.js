// alert("hi!!!!");
// const socket = new WebSocket("http://localhost:3000")

// const socket = new WebSocket("ws://localhost:3000")
// const socket = new WebSocket(`ws://${window.localhost.host}`);
// 에러 const socket = new WebSocket("ws://${window.location.host}");

 const socket = new WebSocket(`ws://${window.location.host}`);

 socket.addEventListener("open",(event)=>{
    console.log("Connected to Server",event.currentTarget.url);
 })

//  socket.addEventListener("message",(message)=> {
//     console.log("Just got this",message,"from the Server");
//  })
//  message의 구조체는 아래와 같다.
// {isTrusted: true, data: 'Hello!!', origin: 'ws://localhost:3000', lastEventId: '', source: null, …} from the Server

socket.addEventListener("message",(message)=> {

    console.log(message.data)
 })
 socket.addEventListener("close",(event)=>{
    console.log("Disconnected from Server",event.currentTarget.url);
 })

 setTimeout( () => {
    socket.send("Hello From Brower!");
 },5000);
