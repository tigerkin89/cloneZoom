
// console.log("hello")
// WebSocket을 이용하기 위해 hppt, WebSocket import
import http from "http";
import WebSocket from "ws";


import express from 'express';

const app = express();

// 뷰엔진 설정하기
app.set("view engine","pug");
app.set("views", __dirname +"/views");
app.use("/public",express.static(__dirname + "/public"));

app.get("/",(req,res) => res.render("home"));
app.get("/*",(req,res) =>res.redirect("/"));

const handleListen = () => console.log("Listening on http://localhost:3000");

//02-2 Express 서버에 websocket 기능 추가 하기
//app.listen(3000,handleListen);

const server = http.createServer(app);
//HTTP 서버위에 웹소켓 서버를 추가하기
const wss = new WebSocket.Server({server});

//02-4 직관적으로 코드 수정
//변경전
// function handleConnection(socket){
//     console.log(socket)
//   }
// //02-3 웹소켓 이벤트 핸들링 
// wss.on("connection",handleConnection)

wss.on("connection",(socket) =>{
    // console.log(socket);
    console.log("Connected to Brower");
    socket.on("close",() => {
        console.log("Disconnect from Broser1")
    });
    socket.on("message", (message) => {
        console.log( `${message}`)
    });
    socket.send("Hello!!");
})

// 아래처럼 하면 안되네..
wss.on("close",(socket) =>{
    // console.log(socket);
    console.log("Disconnect to Brower2 ");
    socket.send("Hello!!");
})



//02-2 Express 서버에 websocket 기능 추가 하기
server.listen(3000,handleListen);