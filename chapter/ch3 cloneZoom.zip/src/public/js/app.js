// alert("hi!!!!");
// const socket = new WebSocket("http://localhost:3000")

// const socket = new WebSocket("ws://localhost:3000")
// const socket = new WebSocket(`ws://${window.localhost.host}`);
// 에러 const socket = new WebSocket("ws://${window.location.host}");

//ch3-1 form 이벤트 등록ㅎ기
// const  messageList = document.querySelector("ul");
// const messageForm = document.querySelector("form");

//ch-3-2 nick/message 처리하기
const  messageList = document.querySelector("ul");
const  nickForm = document.querySelector("#nick");
const  messageForm = document.querySelector("#message");
const socket = new WebSocket(`ws://${window.location.host}`);

socket.addEventListener("open",(event)=>{
    console.log("Connected to Server",event.currentTarget.url);
 })

//  socket.addEventListener("message",(message)=> {
//     console.log("Just got this",message,"from the Server");
//  })
//  message의 구조체는 아래와 같다.
// {isTrusted: true, data: 'Hello!!', origin: 'ws://localhost:3000', lastEventId: '', source: null, …} from the Server

socket.addEventListener("message",(message)=> {

     console.log("Recv : " +message.data)
    // 03-2 서버로부터 수신된 메세지를 브라우저에게 출력하기
    const li = document.createElement("li");
    li.innerText = message.data;
    messageList.append(li)

 })
 socket.addEventListener("close",(event)=>{
    console.log("Disconnected from Server",event.currentTarget.url);
 })

//  setTimeout( () => {
//     socket.send("Hello From Brower!");
//  },5000);

// ch 3-3 JSON을 문자열로 변환
function makeMessage(type,payload) {
    const msg = {type,payload};
    return JSON.stringify(msg)
}

// ch 3-1 form 이벤트 등록하기
function handleSummit(event) {
    event.preventDefault();
    const input = messageForm.querySelector("input");

    // ch 3-4 JSON을 문자열로 변환
    // socket.send(input.value);
    socket.send(makeMessage("new_message",input.value));
    input.value = "";
}


function handleNickSubmit(event) {
    event.preventDefault();
    const input = nickForm.querySelector("input");
    // socket.send(input.value);
    //ch3-2 nick name을 JSON으로 보내기
    // socket.send( {
    //     type:"nickname",
    //     payload :input.value
    // })
    //ch3-3 JSON을 묹열로 변환
    socket.send(makeMessage("nickname",input.value));

    
    input.value="";
}

messageForm.addEventListener("submit",handleSummit);

nickForm.addEventListener("submit",handleNickSubmit);