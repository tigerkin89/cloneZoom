// // alert("hi!!!!");
// // const socket = new WebSocket("http://localhost:3000")

// // const socket = new WebSocket("ws://localhost:3000")
// // const socket = new WebSocket(`ws://${window.localhost.host}`);
// // 에러 const socket = new WebSocket("ws://${window.location.host}");

// //ch3-1 form 이벤트 등록ㅎ기
// // const  messageList = document.querySelector("ul");
// // const messageForm = document.querySelector("form");

// //ch-3-2 nick/message 처리하기
// const  messageList = document.querySelector("ul");
// const  nickForm = document.querySelector("#nick");
// const  messageForm = document.querySelector("#message");
// const socket = new WebSocket(`ws://${window.location.host}`);

// socket.addEventListener("open",(event)=>{
//     console.log("Connected to Server",event.currentTarget.url);
//  })

// //  socket.addEventListener("message",(message)=> {
// //     console.log("Just got this",message,"from the Server");
// //  })
// //  message의 구조체는 아래와 같다.
// // {isTrusted: true, data: 'Hello!!', origin: 'ws://localhost:3000', lastEventId: '', source: null, …} from the Server

// socket.addEventListener("message",(message)=> {

//      console.log("Recv : " +message.data)
//     // 03-2 서버로부터 수신된 메세지를 브라우저에게 출력하기
//     const li = document.createElement("li");
//     li.innerText = message.data;
//     messageList.append(li)

//  })
//  socket.addEventListener("close",(event)=>{
//     console.log("Disconnected from Server",event.currentTarget.url);
//  })

// //  setTimeout( () => {
// //     socket.send("Hello From Brower!");
// //  },5000);

// // ch 3-3 JSON을 문자열로 변환
// function makeMessage(type,payload) {
//     const msg = {type,payload};
//     return JSON.stringify(msg)
// }

// // ch 3-1 form 이벤트 등록하기
// function handleSummit(event) {
//     event.preventDefault();
//     const input = messageForm.querySelector("input");

//     // ch 3-4 JSON을 문자열로 변환
//     // socket.send(input.value);
//     socket.send(makeMessage("new_message",input.value));
//     input.value = "";
// }


// function handleNickSubmit(event) {
//     event.preventDefault();
//     const input = nickForm.querySelector("input");
//     // socket.send(input.value);
//     //ch3-2 nick name을 JSON으로 보내기
//     // socket.send( {
//     //     type:"nickname",
//     //     payload :input.value
//     // })
//     //ch3-3 JSON을 묹열로 변환
//     socket.send(makeMessage("nickname",input.value));

    
//     input.value="";
// }

// messageForm.addEventListener("submit",handleSummit);

// nickForm.addEventListener("submit",handleNickSubmit);

// ch4 socket.io
// 기존 81라인까지는 없애고 새로 시작한다.
// 기존 new WebSocket(`ws://${window.localhost.host}`); 이후의 핸들러 과정은 없애고 새로 시작!!

const socket = io();

const welcome = document.getElementById("welcome");
const form = welcome.querySelector("form");
const room = document.getElementById("room");

room.hidden = true;

let roomName;



function addMessage(message) {
    const ul = room.querySelector("ul");
    const li = document.createElement("li");
    li.innerText = message;
    ul.appendChild(li);
}
// 04-4 message handler는 이벤트를 발생시키고,
// 서버에서 상대방에게 메세지를 전달하는 send_message 이벤트를 전달하고,
// 실행시킬 call back를 정의한다. 
function handleMessageSubmit(event){
    event.preventDefault();
    const input = room.querySelector("input");
    const value = input.value;
    socket.emit("new_message",value,roomName, () => {
        addMessage(`You: ${value}`);
    });
    input.value="";
}
function showRoom() {
    welcome.hidden = true;
    room.hidden = false;
    const h3 = room.querySelector("h3");
    h3.innerText = `Room ${roomName}`;
    //04-4 message send submit 처리를 위한 handler 등록
    const form = room.querySelector("form");
    form.addEventListener("submit",handleMessageSubmit);
  }
function handleRoomSubmit(event){
    event.preventDefault();
    const input = form.querySelector("input");
    //이벤트를 발생하여 서버에게 전달한다. 이벤트이름은 enter_room이다.
    // socket.emit("enter_room",{payload: input.value});

    //이벤트를 발생하여 서버에게 전달한다. 이벤트이름은 enter_room이다.
    //두번째 인자는 서버에 전달할 데이타,
    //세번째 인자는 서버에서 호출할 콜백 함수. 

    // socket.emit("enter_room",input.value, () => {
    //     console.log("server is done!!");
    // });
    //4.3 최초 room form만 보이고, 롬 이름 접속후에는 룸이름 사라지고,
    //    메세지 폼만 보이도록 한다.
    socket.emit("enter_room", input.value, showRoom);
    roomName = input.value;
    input.value = "";
}

form.addEventListener("submit",handleRoomSubmit);
socket.on("welcome" ,() => {
    addMessage("someone join");
})

// 04-5  채팅룸을 나갈때 메세지 표시
socket.on("bye",() => {
    addMessage("someone left ㅠㅠ");
})

//04-5 서버에서 메세지를 보냈다.
socket.on("send_message",(msg) => {
    message = "From : " + msg;
    addMessage(message);
})