
// // console.log("hello")
// // WebSocket을 이용하기 위해 hppt, WebSocket import
// import http from "http";
// import WebSocket from "ws";


// import express from 'express';

// const app = express();

// // 뷰엔진 설정하기
// app.set("view engine","pug");
// app.set("views", __dirname +"/views");
// app.use("/public",express.static(__dirname + "/public"));

// app.get("/",(req,res) => res.render("home"));
// app.get("/*",(req,res) =>res.redirect("/"));

// const handleListen = () => console.log("Listening on http://localhost:3000");

// //02-2 Express 서버에 websocket 기능 추가 하기
// //app.listen(3000,handleListen);

// const server = http.createServer(app);
// //HTTP 서버위에 웹소켓 서버를 추가하기
// const wss = new WebSocket.Server({server});

// //02-4 직관적으로 코드 수정
// //변경전
// // function handleConnection(socket){
// //     console.log(socket)
// //   }
// // //02-3 웹소켓 이벤트 핸들링 
// // wss.on("connection",handleConnection)
// const sockets = [];
// wss.on("connection",(socket) =>{
//     // console.log(socket);
//     //03-2 클라이언트의 접속 정보를 기록ㅎㄴㄷ.
//     sockets.push(socket);
//     //03-4 클라이언트의 닉네임을 초기화한다.
//     socket["nickname"] = 'Annoymous"'
//     console.log("Connected to Brower");
//     socket.on("close",() => {
//         console.log("Disconnect from Broser1")
//     });
//     socket.on("message", (message) => {
//         //03-1 클라이언트 메세지를 돌려준다
//         // console.log( "recv : " +`${message}`)
//         // socket.send(`${message}`);
//         //03-2 모든 클라이언트에게 메세지를 돌려준다
//         // sockets.forEach(aSocket => {
//         //     aSocket.send(`${message}`);
//         // });
//         //03-4 문자열을 JSON으로 변환하기
//         // const msg = JSON.parse(message);
//         // console.log("RECV", msg.type,msg.payload);
//         // sockets.forEach(aSocket => {
//         //     aSocket.send(`${msg}`);
//         // });
//         // 03-4 msg.type별 행동하기, message를 수신하면 전체 전달하고,
//         // nick정보를 저장ㅎㄴ다.
//         const msg = JSON.parse(message);
//         console.log("RECV", msg.type,msg.payload);
//         switch (msg.type) {
//             case "new_message":
//                 sockets.forEach ( aSocket => {
//                     //03-4 익명자 고려
//                     // aSocket.send(`${msg.payload}`);
//                     aSocket.send(`${socket.nickname}: ${msg.payload}` );
//                 });
//                 break;
//             case "nickname":
//                 socket["nickname"] = msg.payload;
//                 break;
//         }
        

//     });
//     // socket.send("Hello!!");
// })

// // 아래처럼 하면 안되네..
// wss.on("close",(socket) =>{
//     // console.log(socket);
//     console.log("Disconnect to Brower2 ");
//     socket.send("Hello!!");
// })



// //02-2 Express 서버에 websocket 기능 추가 하기
// server.listen(3000,handleListen);

// ch4. socket.io를 이용하기
import http from "http";
//socetID import
import SocketIO from "socket.io"
import express from "express";
const app = express();
// 뷰엔진 설정하기
app.set("view engine","pug");
app.set("views", __dirname +"/views");
app.use("/public",express.static(__dirname + "/public"));

app.get("/",(req,res) => res.render("home"));
app.get("/*",(req,res) =>res.redirect("/"));

//http 서버와 웹소켓 서버 구분
const httpServer = http.createServer(app);
const wsServer=SocketIO(httpServer);

//웹소켓 이벤트 등록
wsServer.on("connection", (socket) => {
    // console.log(socket);
    // 클라이언트에서 callback이 정의되지 않은 경우
    // socket.on("enter_room",(roomName) => {
    //     console.log(roomName);
    // });
    //클라이언트에서 callback을 전달한 경우
    socket.on("enter_room",(roomName,done) => {
        console.log(roomName);
        // setTimeout(() => {
        //     done();
        // },5000);
        // 04-3 채팅룸 접속하기
        // socket.io는 사용자들을 room 단위로 묶는 기능을 제공한다.
        // https://socket.io/docs/v4/server-api/#socket 참고

        //4.3 clinet가 전달한 done() 함수를 호출한다.
        // done();
        // console.log("socket.id : ",socket.id);
        // console.log("sockets.rooms : ",socket.rooms);
        // socket.join(roomName);
        // console.log("sockets.rooms : ", socket.rooms);
        //4.4 채팅룸에 참여한 소켓들에 대해서만 welcome 이벤트를 발생시킨다.
        done();
        socket.join(roomName);
        socket.to(roomName).emit("welcome");
    });
    // 04-5  채팅룸을 나갈때 메세지 표시
    socket.on("disconnecting", () => {
        socket.rooms.forEach( room =>
            socket.to(room).emit("bye"));
    });
    //04-5 메세지를 받을때 처리
    socket.on("new_message",(msg,room,done) => {
        console.log("new_message: ",msg);
        socket.to(room).emit("send_message",msg);
        done();
    })
});
const handleListen = () => {
    console.log("Listening on http://localhost:3000");
}
httpServer.listen(3000,handleListen);